package com.universalmusic.app

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer

data class Track(val id: Long, val title: String, val artist: String, val uri: Uri)

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent {
            UniversalMusicApp(
                tracksProvider = { loadDeviceTracks() },
                onPlay = { track -> player.setMediaItem(MediaItem.fromUri(track.uri)); player.prepare(); player.play() },
                onPause = { if (player.isPlaying) player.pause() else player.play() },
                isPlaying = { player.isPlaying }
            )
        }
    }

    private fun loadDeviceTracks(): List<Track> {
        val list = mutableListOf<Track>()
        val collection = if (Build.VERSION.SDK_INT >= 29)
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST)
        contentResolver.query(collection, projection, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
            "${MediaStore.Audio.Media.TITLE} ASC")?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                list += Track(id, cursor.getString(titleCol) ?: "Unknown track",
                    cursor.getString(artistCol) ?: "Unknown artist",
                    ContentUris.withAppendedId(collection, id))
            }
        }
        return list
    }

    override fun onDestroy() {
        player.release()
        super.onDestroy()
    }
}

@Composable
fun UniversalMusicApp(
    tracksProvider: () -> List<Track>,
    onPlay: (Track) -> Unit,
    onPause: () -> Unit,
    isPlaying: () -> Boolean
) {
    val bg = Color(0xFF09090D)
    val surface = Color(0xFF19191F)
    val red = Color(0xFFFF375F)
    var tab by remember { mutableStateOf("Home") }
    var tracks by remember { mutableStateOf(emptyList<Track>()) }
    var selected by remember { mutableStateOf<Track?>(null) }
    var query by remember { mutableStateOf("") }
    var playing by remember { mutableStateOf(false) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) tracks = tracksProvider()
    }
    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) tracks = tracksProvider()
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = bg, surface = surface, primary = red, onBackground = Color.White,
        onSurface = Color.White, secondary = Color(0xFFFF8198)
    )) {
        Scaffold(
            containerColor = bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF121217), contentColor = Color.White) {
                    listOf("Home", "Search", "Library").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = { Icon(when(item) { "Home" -> Icons.Default.Home; "Search" -> Icons.Default.Search; else -> Icons.Default.LibraryMusic }, null) },
                            label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = red, indicatorColor = Color(0xFF35202A))
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("UNIVERSAL", color = Color.LightGray, fontSize = 11.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Bold)
                        Text("MUSIC", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                    }
                    Icon(Icons.Default.Headphones, null, tint = red, modifier = Modifier.size(30.dp))
                }
                when (tab) {
                    "Home" -> {
                        Column(Modifier.padding(horizontal = 18.dp)) {
                            Box(Modifier.fillMaxWidth().height(155.dp).background(
                                Brush.linearGradient(listOf(Color(0xFF5A102B), Color(0xFF191923), Color(0xFF272033))),
                                RoundedCornerShape(24.dp)).padding(20.dp), contentAlignment = Alignment.BottomStart) {
                                Column {
                                    Text("YOUR MUSIC. YOUR WORLD.", color = Color(0xFFFFA5B6), fontSize = 10.sp, letterSpacing = 2.sp)
                                    Text("Every beat,\nevery moment.", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold, lineHeight = 30.sp)
                                }
                            }
                            Spacer(Modifier.height(22.dp))
                            Text("Your Music Library", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                            Text("Play music stored on your device", color = Color.LightGray, fontSize = 13.sp)
                            Spacer(Modifier.height(12.dp))
                            Button(onClick = { launcher.launch(permission) }, colors = ButtonDefaults.buttonColors(containerColor = red)) {
                                Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("Scan device music")
                            }
                            TrackList(tracks.take(8), selected, { selected = it; onPlay(it); playing = true })
                        }
                    }
                    "Search" -> {
                        Column(Modifier.padding(18.dp)) {
                            Text("Search your music", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(12.dp))
                            OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(),
                                placeholder = { Text("Song, artist or album") }, leadingIcon = { Icon(Icons.Default.Search, null) },
                                singleLine = true, shape = RoundedCornerShape(18.dp))
                            Spacer(Modifier.height(12.dp))
                            TrackList(tracks.filter { it.title.contains(query, true) || it.artist.contains(query, true) }, selected,
                                { selected = it; onPlay(it); playing = true })
                        }
                    }
                    else -> {
                        Column(Modifier.padding(18.dp)) {
                            Text("Your Library", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                            Text("${tracks.size} songs found on this device", color = Color.LightGray)
                            Spacer(Modifier.height(16.dp))
                            Button(onClick = { launcher.launch(permission) }, colors = ButtonDefaults.buttonColors(containerColor = red)) {
                                Text("Refresh music library")
                            }
                            TrackList(tracks, selected, { selected = it; onPlay(it); playing = true })
                        }
                    }
                }
                selected?.let { track ->
                    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp)
                        .background(surface, RoundedCornerShape(16.dp)).clickable { onPause(); playing = !playing }
                        .padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(42.dp).background(Brush.linearGradient(listOf(red, Color(0xFF4A1730))), RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null) }
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(track.title, maxLines = 1, fontWeight = FontWeight.SemiBold)
                            Text(track.artist, color = Color.LightGray, fontSize = 12.sp, maxLines = 1)
                        }
                        IconButton(onClick = { onPause(); playing = !playing }) {
                            Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = red)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TrackList(tracks: List<Track>, selected: Track?, onClick: (Track) -> Unit) {
    LazyColumn {
        items(tracks, key = { it.id }) { track ->
            Row(Modifier.fillMaxWidth().clickable { onClick(track) }.padding(vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(46.dp).background(Color(0xFF29232D), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.MusicNote, null, tint = Color(0xFFFF5275))
                }
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    Text(track.title, color = Color.White, fontWeight = if (selected?.id == track.id) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
                    Text(track.artist, color = Color.LightGray, fontSize = 12.sp, maxLines = 1)
                }
                Icon(Icons.Default.MoreHoriz, null, tint = Color.LightGray)
            }
        }
    }
}
